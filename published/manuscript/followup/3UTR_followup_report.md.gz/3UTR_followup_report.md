# 3′ UTR follow-up investigation

Analysis completed 14 November 2026. Existing manuscript figures, notebooks, and source result tables were not edited. All new work is isolated under `local/utr3-followup-2026-11-14`.

**Main assessment:** The full dataset contains a negative, adjusted within-gene association between annotated 3′ UTR length and the ASD–Unaffected P/M response. Several transcript-level checks support that pattern. However, new culture-omission analyses show that its direction and strength are sensitive to the individual cultures included. It should remain an exploratory architecture association, not a settled biological mechanism.

**The most consequential finding is culture sensitivity.** I reconstructed the original rounded lengthScaledTPM counts and fitted the original participant/culture-paired fraction-interaction design in R DESeq2. Original fraction size factors and original transcript dispersions were held fixed to isolate the influence of each culture. Each omission removes all three RNA fractions for that culture. This is a controlled sensitivity refit, not a complete PyDESeq2 rerun with re-estimated dispersions.

The architecture regressions use the original seven features plus log abundance and logit mean gene proportion, centered within parent gene and globally standardized, with parent-gene-clustered standard errors. The table uses the Wald-statistic outcome used in Figure 3C. A fixed intersection of converged transcripts is used across all seven fits.

| Culture omitted | Broader fixed population: β [95% CI] | Well-measured fixed population: β [95% CI] |
|---|---|---|
| None | -0.067 [-0.092, -0.043] | -0.092 [-0.140, -0.044] |
| Unaffected 07c06 | -0.134 [-0.162, -0.107] | -0.131 [-0.181, -0.081] |
| Unaffected 07c13 | -0.065 [-0.089, -0.041] | -0.098 [-0.145, -0.051] |
| Unaffected 07c16 | +0.038 [+0.013, +0.063] | -0.005 [-0.053, +0.043] |
| ASD 1851 | -0.122 [-0.148, -0.097] | -0.151 [-0.198, -0.103] |
| ASD 1861 | -0.022 [-0.046, +0.002] | -0.035 [-0.083, +0.012] |
| ASD 1916 | -0.014 [-0.038, +0.011] | -0.050 [-0.100, +0.000] |

Broader population: **11,610 transcripts, 3,823 genes**. Well-measured population: **4,096 transcripts, 1,415 genes**, requiring both Monosome and Polysome TPM ≥1 and raw Salmon estimated counts ≥10 for each transcript in every one of the six cultures, then at least two transcripts per gene. No pseudocounts were used. The confidence intervals describe the across-transcript architecture model with clustering by gene; they are not population-level donor replication intervals.

When 07c16 is omitted, the negative association reverses in the broader population and becomes approximately zero in the well-measured population. Omitting ASD culture 1861 or 1916 also yields a 95% interval including zero. Direct geometric-mean TPM P/M calculations on the same well-measured transcripts independently show the same attenuation after removing 07c16.

**The coding-length association is also culture-sensitive.** In the well-measured population, the CDS coefficient is +0.119 [+0.074, +0.164] with all cultures and +0.016 [-0.024, +0.055] after omitting 07c16. Thus the concern extends to the strength of Figure 3C’s architecture interpretation, not only to a proposed 3′ UTR follow-up panel.

**QC provides a reason to investigate 07c16, not a reason to exclude it.** Its Polysome STAR uniquely aligned rate is 77.7%, versus 87.5–90.4% for the other five Polysome libraries; Picard duplication is 88.1%, versus 56.6–86.2%. Its Qualimap 5′–3′ bias is 1.16, within the other Polysome libraries’ range (1.14–1.22). These metrics do not identify the cause of its architecture pattern, prove a technical artifact, or justify outcome-based exclusion.

**Results supporting the association in the complete dataset**

| Check using P/M log2 fold change | Transcripts / genes | 3′ UTR standardized β [95% CI] | Exploratory nominal p |
|---|---:|---|---:|
| Original adjusted fold-change model | 11,679 / 3,843 | -0.127 [-0.152, -0.102] | 1.05e-22 |
| Compare identical CDS sequences within gene | 2,328 / 886 | -0.095 [-0.150, -0.040] | 0.000706 |
| Compare identical CDS and 5′ UTR sequences | 154 / 69 | -0.241 [-0.426, -0.055] | 0.0118 |
| Both/all retained isoforms have mean gene proportion ≥10% | 5,424 / 2,499 | -0.186 [-0.228, -0.144] | 9.31e-18 |
| Require model baseMean ≥500 | 6,364 / 2,495 | -0.179 [-0.217, -0.141] | 2.54e-20 |
| Exclude 50 largest absolute covariance contributors | 11,430 / 3,793 | -0.090 [-0.112, -0.069] | 2.1e-16 |
| Additionally adjust 3′ UTR GC fraction | 11,645 / 3,837 | -0.136 [-0.163, -0.108] | 1.27e-21 |

The original fold-change coefficients were reproduced to numerical precision before follow-up fits. Exact sequence identity was verified against the run-matched transcript FASTA, rather than inferred from similar annotated lengths. Identical CDS/5′ UTR groups may still differ in 3′ UTR splicing or sequence composition; they do not necessarily represent tandem alternative polyadenylation. The matched analyses support separation from coding length but use the same six cultures and do not resolve culture sensitivity.

The largest single gene accounts for only 0.75% of absolute adjusted 3′ UTR–response covariance. Removing the 50 largest contributors retains the negative association. Thus no single gene drives the pooled feature association; this is distinct from the finding that individual cultures strongly influence it.

**Magnitude depends on the abundance adjustment.** For the fold-change outcome in the same 11,679 transcripts, β is −0.127 using count-based abundance plus gene proportion, −0.034 when replacing count abundance with mean TPM, and −0.030 without either abundance/proportion covariate. Without those covariates, the original Wald-outcome association is not significant (recorded BH-adjusted p=0.430). In the identical-CDS/5′ UTR subset, the adjusted fold-change coefficient is −0.241 (nominal p=0.0118), while the coefficient without abundance/proportion adjustment is −0.063 (p=0.305). The evidence therefore concerns a conditional association, and its magnitude is model-sensitive.

**ASD-associated and synaptic genes do not show a detectable stronger length effect.** Among genes eligible for the main architecture model, only 56 are in Fu’s ASD185 set, and 527 are in the union of the supplied SynGO sets. Explicit length-by-gene-set interaction tests give nominal p=0.836 for ASD185 and p=0.416 for SynGO. The negative association remains after excluding either set. This is absence of evidence for effect modification, with limited power for ASD185; it does not establish that the mechanisms are identical in all genes.

**Input does not show the same negative length pattern.** The existing full Input architecture model has a positive 3′ UTR Wald association (β=+0.052, BH-adjusted p=1.03×10⁻⁷); the Polysome association is negative and the Monosome association is approximately zero. To avoid comparing only different transcript populations, I also fitted all four existing fold-change outcomes in the same 9,372 transcripts / 3,052 genes with identical covariates. Coefficients are Input +0.031 (nominal p=0.099), Monosome −0.006 (p=0.692), Polysome −0.172 (p=1.31e-27), and P/M −0.123 (p=2.2e-15). Directionally, this is compatible with relatively reduced Polysome representation beyond the Input abundance signal. It does not demonstrate a positive Input effect in that common population, nor does comparing two p-values formally test their difference. Independent fraction models are not assumed algebraically identical to the paired P/M model.

**No compelling individual-gene 3′ UTR discovery emerged.** I selected one pair per gene by the largest eligible 3′ UTR length contrast, without using effect size, significance, or gene-set membership. Requiring identical CDS/5′ UTR sequences, short UTR ≥50 nt, length difference ≥100 nt, and a ≥1.5-fold length ratio yields 29 genes. None of the individual transcripts in these selected pairs has P/M BH-adjusted p<0.05. Restricting matched-group models to ≥1.5-fold UTR length contrasts leaves 74 transcripts /30 genes and a negative, imprecise coefficient (β=−0.225; nominal p=0.145).

Illustrations below are descriptive, not new significant isoform/DTU findings. Δ is the long-minus-short ASD–Unaffected P/M log2 fold-change difference.

| Gene | Short / long 3′ UTR (nt) | Δ from fitted model | Individual short / long P/M BH p | Note |
|---|---:|---:|---|---|
| CDK9 | 1,249 / 3,328 | -0.468 | 0.157 / 0.985 | Nested 3′ UTR; sufficiently measured in all cultures; same direction in all omissions |
| HOXA2 | 372 / 748 | -0.639 | 0.962 / 0.810 | Nested 3′ UTR; sufficiently measured in all cultures; same direction in all omissions |
| MAP1LC3A | 181 / 447 | -0.767 | 0.825 / 0.893 | Different 3′ UTR sequences; SynGO member; same direction in all omissions |

A stronger tandem-UTR screen requiring a ≥500-nt extension and the short UTR to be an exact prefix of the long UTR yields only three genes; only CDK9 passes the all-culture measurement thresholds. That is insufficient to establish a global alternative-polyadenylation result. In CDK9, both fitted transcript P/M responses are positive (+0.610 short, +0.142 long), illustrating why a relatively lower response for the long isoform does not imply that its absolute P/M response decreases. Neither individual response is significant after BH correction.

**Biological interpretation and unanswered questions.** 3′ UTR sequences can regulate neuronal RNA localization, stability, and translation; see [Tushev et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29656876/) and [Taliaferro et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26907613/). CPEB4-mediated regulation of poly(A) tails provides an autism-relevant mechanistic precedent, rather than evidence of that mechanism here: [Parras et al., 2018](https://pubmed.ncbi.nlm.nih.gov/30111840/). None of the selected gene-level regulators (CPEB1–4, FMR1, MBNL1–2, ELAVL1–4, PUM1–2) is significant in the supplied Input or P/M gene results. That does not exclude altered regulator protein abundance, activity, binding, or splicing.

These data do not measure poly(A)-tail length, RBP occupancy, miRNA activity, or neuronal subcompartment localization. Annotated 3′ UTR length is fixed for each reference transcript: the architecture regression does not demonstrate condition-dependent UTR shortening. The transcript-derived gene tests and the formal differential transcript-usage tests are different analyses; there are no confirmed redistribution DTU genes in the available results. Salmon inferential replicates are unavailable, so uncertainty in short-read assignment to overlapping isoforms remains unresolved. P/M association is not a direct measurement of absolute ribosome number or protein production. There is one sibling pair with three cultures/preparations per background; these are not six independent donors.

**Implication for the manuscript.** Preserve the observed full-data association as an exploratory result, explicitly report its adjustment and culture sensitivity, and avoid describing it as a demonstrated autism mechanism. Prioritize an audit of culture 07c16 and a complete normalization/dispersion-refitted culture sensitivity analysis before building Figure 3D around a strong 3′ UTR explanation. The current controlled refits and direct TPM calculations already establish that transcript-level filters alone are insufficient robustness evidence.

**Inference, validation, and reproduction**

New p-values in this report are exploratory, unadjusted sensitivity/interaction p-values. Numerous related fits were examined; they are not independent confirmatory discoveries. Previously recorded BH-adjusted p-values are identified separately. All model tables include sample sizes, coefficient standard errors, degrees of freedom, and 95% intervals.

The R full-count refit is an independent implementation using the same original counts, size factors, dispersions, and interaction design. Median absolute P/M log2-effect discrepancy versus source is 2.66×10⁻⁷; the 95th percentile is 0.00351, with larger discrepancies in a small low-abundance tail. The primary Wald architecture coefficient is reproduced closely. Well-measured transcript refits reproduce the original architecture coefficients to approximately 2×10⁻⁵ or better. All seven R fits use original full-data dispersions and size factors, not re-estimated ones. The all-omission comparison freezes genes/transcripts after requiring convergence in every refit.

Reproduction order: `investigate_utr3.py`, `investigate_utr3_stage2.py`, `investigate_utr3_stage3.py`, `extract_multiqc.py`, `reconstruct_count_model.py`, `refit_fixed_dispersion_NB.R`, `analyze_NB_sensitivity.py`, `analyze_all_NB_omissions.py`, `model_inference.R`, and this packaging script. Additional one-off regulator and QC extractions are preserved in the output CSVs. The R refit script reuses completed isolated refit CSVs; clear those task-local caches before refitting if source inputs change. Source reference paths and Python dependency locations are those installed on this PC.

Key files: `all_models_with_inference.csv`; `NB_omissions_Wald_summary.csv`; `same_CDS_5UTR_large_contrast_pairs.csv`; `same_CDS_5UTR_pair_culture_profiles.csv`; `library_QC_followup.csv`; `selected_UTR_regulators_gene_results.csv`; and `summary.json` (source SHA-256 checksums).
